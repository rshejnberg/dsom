require 'test_helper'

class ContactmeTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
