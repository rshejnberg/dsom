require 'test_helper'

class SupportsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
