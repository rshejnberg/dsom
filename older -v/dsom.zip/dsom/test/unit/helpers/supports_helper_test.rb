require 'test_helper'

class SupportsHelperTest < ActionView::TestCase
end
