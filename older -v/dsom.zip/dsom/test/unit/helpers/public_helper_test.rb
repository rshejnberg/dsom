require 'test_helper'

class PublicHelperTest < ActionView::TestCase
end
