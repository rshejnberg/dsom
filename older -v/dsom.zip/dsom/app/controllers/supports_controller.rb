class SupportsController < ApplicationController
end
