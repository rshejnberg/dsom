class Support < ActiveRecord::Base
  # attr_accessible :title, :body
end
